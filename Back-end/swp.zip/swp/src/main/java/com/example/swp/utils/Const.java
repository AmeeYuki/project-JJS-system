package com.example.swp.utils;

public class Const {
    public final static class SEND_MAIL_SUBJECT {
        public final static String USER_REGISTER = "XÁC NHẬN TẠO MỚI THÔNG TIN NHÂN VIÊN";

        public final static String OTP_SEND = "MÃ OTP XÁC THỰC";
    }

    public final static class TEMPLATE_FILE_NAME {
        public final static String USER_REGISTER = "USER";
        public final static String OTP_SEND = "OTP";
    }
}