package com.example.swp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SwpApplicationTests {

	@Test
	void contextLoads() {
	}

}
